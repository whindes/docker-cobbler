#!/usr/bin/env node
const localIpV4Address = require("local-ipv4-address");

localIpV4Address().then(function(ipAddress){
    //process.env.LOCAL_IP = ipAddress
    console.log(ipAddress);
    // My IP address is 10.4.4.137
});